.. _ref_core_session:

=================
Session Reference
=================

.. automodule:: boto3.session
   :members:
   :undoc-members:
